import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

settings = xbmcaddon.Addon(id='script.module.xbmc.helpers')
version = "2.1.1"
plugin = "XBMCHelpers-" + version
